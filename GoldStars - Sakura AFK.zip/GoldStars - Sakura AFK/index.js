const mineflayer = require('mineflayer');
require('@wlac/cc');
const utils = require('./utils');
const colors = require('colors');
const fs = require('fs');

mineflayer.multiple = async (bots, constructor) => {
  const { Worker, isMainThread, workerData } = require('worker_threads');
  if (isMainThread) {
    const threads = [];
    for (const i in bots) {
      await utils.sleep(6000);
      threads.push(new Worker(__filename, { workerData: bots[i] }));
    }
  } else {
    constructor(workerData);
  }
};

const accounts = [];
const accountFile = 'accounts.txt';
const accountsFileData = fs.readFileSync(accountFile, 'utf8');
for (const account of accountsFileData.split('\r\n')) {
  const splitted = account.split(':');
  if (splitted.length === 4) {
    accounts.push({ username: splitted[0], pass: splitted[1], home: splitted[2], auth: splitted[3] });
  }
}

const bot_creator = ({ username, pass, home, auth }) => {
  const bot = mineflayer.createBot({
    username,
    host: 'gladmc.com',
    port: 25565,
    checkTimeoutInterval: 600000,
    brand: 'LunarClient:a1f71bc',
    version: '1.18',
    auth,
    pass,
    home
  });

  bot.location = 'unknown';
  bot.isRestarting = false;
  bot.disconnected = false;

  bot.once('login', () => logConnection(username));
  bot.on('spawn', () => handleSpawn(bot, home, username));
  bot.on('message', (message) => handleMessage(bot, message, pass));
  bot.on('end', (reason) => handleDisconnect(bot, reason, username, home, auth));

  return bot; // Retorna o bot para possível uso futuro
};

const logConnection = (username) => {
  console.log("Conectando > ".brightMagenta + username);
};

const handleSpawn = async (bot, home, username) => {
  await utils.sleep(1500);
  await utils.getLocation(bot, home, async () => {
    if (bot.location === 'home') {
      console.log(`${username} chegou na home (/pw${home})`);
    }
  });
};

const handleMessage = async (bot, message, pass) => {
  console.log(message.toAnsi());
  
  if (message.toString().includes('Use o comando "/login <senha>" para logar no servidor.')) {
    bot.chat(`/login ${pass}`);
  } else if (message.toString().startsWith('Servidor está reiniciando')) {
    console.log(`Servidor reiniciando, desconectando: ${bot.username}`.cyan);
    bot.isRestarting = true;
    bot.quit();
  }
};

const handleDisconnect = async (bot, reason, username, home, auth) => {
  if (reason.includes('quitting') && bot.isRestarting) {
    cleanUp(bot);
    console.log(`${username} aguardando 5 min para reconectar`.brightMagenta);
    await utils.sleep(360000);
    bot.isRestarting = false;
    bot_creator({ username, pass, home, auth });
  } else if (reason.includes('quitting') && bot.disconnected) {
    console.log('Desligando a conta.');
  } else {
    cleanUp(bot);
    console.log(`${username} foi desconectado, reconectando...`.brightRed);
    await utils.sleep(7500);
    bot_creator({ username, pass, home, auth });
  }
};

const cleanUp = (bot) => {
  bot.removeAllListeners();
  if (bot._client) {
    bot._client.removeAllListeners();
  }
};

mineflayer.multiple(accounts, bot_creator);
