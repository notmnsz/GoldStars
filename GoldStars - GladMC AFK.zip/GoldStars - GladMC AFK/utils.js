const moment = require('moment');
const math = require('math');

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function enterRankup(bot) {
    await closeCurrentWindow(bot);
    bot.setQuickBarSlot(4);
    bot.activateItem();

    bot.once('windowOpen', async (window) => {
        if (window.title.includes('Modos de Jogo')) {
            log(`Janela identificada: 'Modos de Jogo'`, 'grey');
            await bot.clickWindow(10, 0, 0);
        }
    });

    await sleep(3000);
    await checkRankupWindow(bot);
}

async function closeCurrentWindow(bot) {
    if (bot.currentWindow) {
        bot.closeWindow(bot.currentWindow);
    }
}

async function checkRankupWindow(bot) {
    if (bot.currentWindow?.title?.includes('Modos de Jogo')) {
        console.log('Não entrou no rankup?');
        await enterRankup(bot); // Retentativa se não entrar
    }
}

async function getLocation(bot, home) {
    const onMessage = async (message) => {
        if (message.includes('Teletransportado com sucesso')) {
            log(`${bot.username} chegou na home com sucesso!`, 'brightGreen');
            bot.location = 'home';
            bot.removeListener('messagestr', onMessage);
        } else if (message.includes('Cancelado, você moveu!')) {
            log(`${bot.username} não conseguiu chegar na home`, 'brightRed');
            bot.removeListener('messagestr', onMessage);
            await sleep(2500);
            bot.chat(`${home}`);
        }
    };

    let coords = bot.entity.position;
    if (math.trunc(coords.z) === 0 && math.trunc(coords.x) === 0) {
        const block = bot.blockAt(bot.entity.position.offset(0, -50, 0));
        if (block) {
            if (['air', 'stone'].includes(block.name)) {
                bot.location = 'rankup';
                console.log('Lobby/Rankup identificado');
                bot.on('messagestr', onMessage);
                await proceedToFullPvP(bot, home);
            }
        }
    }
}

async function proceedToFullPvP(bot, home) {
    await sleep(500);
    log(`indo até o fullpvp`, 'grey');
    bot.chat(`/sv`);
    bot.on('windowOpen', (window) => {
        bot.clickWindow(10, 0, 0);
    });
    await sleep(1500);
    log(`Indo até a home: ${home}`, 'grey');
    bot.chat(`${home}`);
}

async function getCurrentTime() {
    return (new moment()).format("HH:mm:ss");
}

async function log(message, color) {
    const time = await getCurrentTime();
    console.log(`[${time}] ${message}`[color]);
}

async function logAccount(user, message) {
    await log('[' + user + '] ' + message);
}

module.exports = {
    sleep,
    log,
    logAccount,
    getLocation,
    getCurrentTime,
    enterRankup
};
