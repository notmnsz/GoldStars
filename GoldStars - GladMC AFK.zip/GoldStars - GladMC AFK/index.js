const mineflayer = require('mineflayer');
require('@wlac/cc');
const utils = require('./utils');
const colors = require('colors');
const fs = require('fs');

mineflayer.multiple = async (bots, constructor) => {
  const { Worker, isMainThread, workerData } = require('worker_threads');
  if (isMainThread) {
    const threads = [];
    for (const i in bots) {
      await utils.sleep(6000);
      threads.push(new Worker(__filename, { workerData: bots[i] }));
    }
  } else {
    constructor(workerData);
  }
};

const accounts = loadAccounts('accounts.txt');

function loadAccounts(file) {
  const accounts = [];
  const accountsFileData = fs.readFileSync(file, 'utf8');
  for (const account of accountsFileData.split('\r\n')) {
    const splitted = account.split(':');
    if (splitted.length === 4) {
      accounts.push({ username: splitted[0], pass: splitted[1], home: splitted[2], auth: splitted[3] });
    }
  }
  return accounts;
}

const bot_creator = ({ username, pass, home, auth }) => {
  const bot = mineflayer.createBot({
    username,
    host: 'gladmc.com',
    port: 25565,
    checkTimeoutInterval: 600000,
    brand: 'LunarClient:a1f71bc',
    version: '1.18',
    auth,
    pass,
    home,
  });

  bot.location = 'unknown';
  bot.isRestarting = false;
  bot.disconnected = false;

  bot.once('login', () => logConnection(username));

  bot.on('spawn', () => handleSpawn(bot, home, username));

  bot.on('message', (message) => handleMessage(bot, message, pass));

  bot.on('end', (reason) => handleDisconnect(bot, reason, username, home, auth));
};

const logConnection = (username) => {
  console.log("Conectando > ".brightMagenta + username);
};

const handleSpawn = async (bot, home, username) => {
  await utils.sleep(1500);
  await utils.getLocation(bot, home, () => {
    if (bot.location === 'home') {
      console.log(`${username} chegou na home (/pw${home})`);
    }
  });
};

const handleMessage = (bot, message, pass) => {
  console.log(message.toAnsi());
  if (message.toString().includes('Use o comando "/login <senha>" para logar no servidor.')) {
    bot.chat(`/login ${pass}`);
  } else if (message.toString().startsWith('Servidor está reiniciando')) {
    console.log(`Servidor reiniciando, desconectando: ${bot.username}`.cyan);
    bot.isRestarting = true;
    bot.quit();
  }
};

const handleDisconnect = async (bot, reason, username, home, auth) => {
  bot.removeAllListeners();
  
  if (reason.includes('quitting') && bot.isRestarting) {
    await reconnectAfterDelay(username, 300000, home, auth);
  } else if (reason.includes('quitting') && bot.disconnected) {
    console.log('Desligando a conta.');
  } else {
    console.log(`${username} foi desconectado, reconectando...`.brightRed);
    await reconnectAfterDelay(username, 7500, home, auth);
  }
};

const reconnectAfterDelay = async (username, delay, home, auth) => {
  utils.log(`${username} aguardando ${delay / 1000} segundos para reconectar`, 'brightMagenta');
  await utils.sleep(delay);
  bot_creator({ username, pass: accounts.find(acc => acc.username === username).pass, home, auth });
};

mineflayer.multiple(accounts, bot_creator);
