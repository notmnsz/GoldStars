const moment = require('moment')
const math = require('math');

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getLocation(bot, home, cb) {

    const onMessage = async (message) => {
        if (message.includes('Teletransportado com sucesso')) {
            log(`${bot.username} chegou na home com sucesso!`, 'brightGreen')
            bot.location = 'home'
            bot.removeListener('messagestr', onMessage)
        }

        else if (message.includes('Cancelado, você moveu!')) {
            log(`${bot.username} não conseguiu chegar na home`, 'brightRed')
            await sleep(2500)
            bot.chat(`${home}`)
        }

        else if (message.includes('Unknown command. Type "/help" for help.')) {
            log(`indo até o fp sakura`, 'grey')
            bot.setQuickBarSlot(4);
            bot.activateItem();
            bot.on('windowOpen', function(window) {
                bot.clickWindow(10, 0, 0);
              });
              await sleep(1500)
              log(`Indo até a home: ${home}`, 'grey')
              bot.chat(`${home}`)
        }
    }

    let coords = bot.entity.position
    if (math.trunc(coords.z) === 0 && math.trunc(coords.x) === 0) {
        const block = bot.blockAt(bot.entity.position.offset(0, -8, 0))
        if (!block) return;
        if (block.name === 'air') {
            bot.location = 'rankup'
            console.log('Lobby/Rankup identificado')
            bot.on('messagestr', onMessage)
            await sleep(500)
            log(`indo até o fullpvp`, 'grey')
            bot.setQuickBarSlot(4);
            bot.activateItem();
            bot.on('windowOpen', function(window) {
                bot.clickWindow(10, 0, 0);
              });
              await sleep(5500)
              log(`Indo até a home: ${home}`, 'grey')
              bot.chat(`${home}`)
        }
        if (block.name === 'stained_glass') {
            bot.location = 'rankup'
            console.log('Lobby/Rankup identificado')
            bot.on('messagestr', onMessage)
            await sleep(500)
            log(`indo até o fullpvp`, 'grey')
            bot.setQuickBarSlot(4);
            bot.activateItem();
            bot.on('windowOpen', function(window) {
                bot.clickWindow(10, 0, 0);
              });
              await sleep(5500)
              log(`Indo até a home: ${home}`, 'grey')
              bot.chat(`${home}`)
        }
        cb()
    }
}

async function getCurrentTime() {
    return (new moment()).format("HH:mm:ss");
}
async function log(message, color) {
    let time = await getCurrentTime();
    console.log(`[${time}] ${message}`[color]);
}

async function logAccount(user, message) {
    log('[' + user + '] ' + message);
}

module.exports = {
    sleep,
    log,
    logAccount,
    getLocation,
    getCurrentTime
}